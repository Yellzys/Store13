import { createBrowserRouter, RouterProvider, Outlet } from "react-router-dom"
import { Header } from './components/Header'
import { TopBar } from './components/TopBar'
import { HeroSlider } from './components/HeroSlider'
import { Categories } from './components/Categories'
import { FlashSale } from './components/FlashSale'
import { Footer } from './components/Footer'
import { AppDownload } from './components/AppDownload'
import { Login } from './pages/Login'
import { Signup } from './pages/Signup'

function HomePage() {
  return (
    <>
      <TopBar />
      <Header />
      <main>
        <HeroSlider />
        <div className="container-daraz pb-10 pt-4">
          <div className="flex gap-4">
            <div className="hidden w-[200px] flex-shrink-0 lg:block">
              <Categories />
            </div>
            <div className="flex-1">
              <FlashSale />
              {/* Other sections would go here */}
            </div>
            <div className="hidden w-[200px] flex-shrink-0 lg:block">
              <AppDownload />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}

const router = createBrowserRouter([
  {
    path: "/",
    element: <HomePage />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/signup",
    element: <Signup />,
  },
]);

function App() {
  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <RouterProvider router={router} />
    </div>
  )
}

export default App
