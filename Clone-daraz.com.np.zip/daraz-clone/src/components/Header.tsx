import { Search, ShoppingCart } from "lucide-react"
import { Link } from "react-router-dom"

export const Header = () => {
  return (
    <header className="bg-white py-3 shadow-sm">
      <div className="container-daraz flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Link to="/" className="flex-shrink-0 transition-transform duration-300 ease-apple hover:scale-105">
            <div className="font-bold text-2xl text-yellzy-yellow">
              Yellzy's <span className="text-yellzy-dark">Store</span>
            </div>
          </Link>

          <div className="relative hidden w-[600px] lg:block">
            <div className="flex">
              <input
                type="text"
                placeholder="Search in Yellzy's Store"
                className="w-full rounded-l-sm border border-gray-300 px-3 py-2 outline-none transition-all duration-300 ease-apple focus:border-yellzy-yellow focus:ring-2 focus:ring-yellzy-yellow/20"
              />
              <button className="flex h-full items-center justify-center rounded-r-sm bg-yellzy-yellow px-4 text-yellzy-dark transition-all duration-300 ease-apple hover:bg-yellzy-dark hover:text-white">
                <Search size={18} />
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Link
            to="/cart"
            className="relative transition-transform duration-300 ease-apple hover:scale-110"
          >
            <ShoppingCart size={24} />
            <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-yellzy-yellow text-xs text-yellzy-dark">
              0
            </span>
          </Link>
        </div>
      </div>
    </header>
  )
}
