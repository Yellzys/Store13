import { Clock } from "lucide-react"
import { useEffect, useState } from "react"

export const FlashSale = () => {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 300)

    return () => clearTimeout(timer)
  }, [])

  const products = [
    {
      id: 1,
      name: "Gay",
      price: 6,
      originalPrice: 12,
      discount: "50%",
      sold: 10,
    },
    {
      id: 2,
      name: "Gay",
      price: 6,
      originalPrice: 12,
      discount: "50%",
      sold: 5,
    },
    {
      id: 3,
      name: "Gay",
      price: 6,
      originalPrice: 12,
      discount: "50%",
      sold: 8,
    },
    {
      id: 4,
      name: "Gay",
      price: 6,
      originalPrice: 12,
      discount: "50%",
      sold: 3,
    },
  ]

  return (
    <div
      className={`mb-6 overflow-hidden rounded-lg bg-white shadow-lg transition-all duration-700 ease-apple ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
    >
      <div className="border-b border-gray-200 bg-gradient-to-r from-yellzy-yellow to-yellzy-yellow p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-yellzy-dark">FLASH SALE</h2>
            <div className="flex items-center rounded-full bg-yellzy-dark/10 px-3 py-1 text-xs text-yellzy-dark">
              <Clock size={14} className="mr-1 animate-pulse-light" />
              <span>ENDING SOON</span>
            </div>
          </div>
          <a
            href="#"
            className="rounded-full bg-yellzy-dark px-4 py-1 text-sm font-medium text-white transition-transform duration-300 ease-apple hover:scale-105 active:scale-95"
          >
            SHOP MORE
          </a>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 p-4 md:grid-cols-4">
        {products.map((product, index) => (
          <div
            key={product.id}
            className="group overflow-hidden rounded-lg border border-transparent transition-all duration-500 ease-apple hover:border-yellzy-yellow hover:shadow-lg"
            style={{
              transitionDelay: `${index * 100}ms`,
              animation: `fade-in 0.5s ease-apple forwards ${index * 100 + 300}ms`
            }}
          >
            <a href={`/product/${product.id}`} className="block p-3">
              <div className="mb-3 aspect-square overflow-hidden rounded-lg bg-yellzy-yellow/10 transition-transform duration-500 ease-apple group-hover:scale-105">
                <div className="flex h-full w-full items-center justify-center">
                  <span className="text-4xl transition-transform duration-500 ease-apple group-hover:scale-110 group-hover:rotate-12">👨‍❤️‍👨</span>
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="font-medium text-yellzy-dark transition-colors duration-300 ease-apple group-hover:text-yellzy-yellow">
                  {product.name}
                </h3>
                <div className="flex items-baseline gap-2">
                  <span className="font-semibold text-yellzy-dark">Rs.{product.price}</span>
                  <span className="text-xs text-gray-500 line-through">Rs.{product.originalPrice}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="inline-block rounded-full bg-yellzy-yellow/20 px-2 py-1 text-xs font-medium text-yellzy-dark">
                    -{product.discount}
                  </span>
                  <span className="text-xs text-gray-500">
                    {product.sold > 0 ? `${product.sold} sold` : ""}
                  </span>
                </div>
              </div>
            </a>
          </div>
        ))}
      </div>
    </div>
  )
}
