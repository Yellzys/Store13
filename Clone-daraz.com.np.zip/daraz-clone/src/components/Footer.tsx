export const Footer = () => {
  return (
    <footer className="border-t border-gray-200 bg-white pt-10">
      <div className="container-daraz">
        <div className="grid grid-cols-1 gap-8 pb-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <h4 className="mb-4 font-medium text-daraz-dark">Customer Care</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-daraz-primary">Help Center</a></li>
              <li><a href="#" className="hover:text-daraz-primary">How to Buy</a></li>
              <li><a href="#" className="hover:text-daraz-primary">Returns & Refunds</a></li>
              <li><a href="#" className="hover:text-daraz-primary">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-medium text-daraz-dark">Daraz</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-daraz-primary">About Daraz</a></li>
              <li><a href="#" className="hover:text-daraz-primary">Daraz Blog</a></li>
              <li><a href="#" className="hover:text-daraz-primary">Daraz Careers</a></li>
              <li><a href="#" className="hover:text-daraz-primary">Terms & Conditions</a></li>
              <li><a href="#" className="hover:text-daraz-primary">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-daraz-primary">Digital Payments</a></li>
              <li><a href="#" className="hover:text-daraz-primary">Daraz Customer Care</a></li>
            </ul>
          </div>

          <div className="text-center md:text-left">
            <h4 className="mb-4 font-medium text-daraz-dark">Happy Shopping</h4>
            <p className="mb-4 text-sm text-gray-600">Download App</p>
            <div className="flex flex-wrap justify-center gap-2 md:justify-start">
              <a href="#" className="block">
                <img
                  src="https://ext.same-assets.com/2128267916/3282241916.png"
                  alt="App Store"
                  className="h-10"
                />
              </a>
              <a href="#" className="block">
                <img
                  src="https://ext.same-assets.com/1541928389/819352697.png"
                  alt="Google Play"
                  className="h-10"
                />
              </a>
            </div>
          </div>

          <div>
            <h4 className="mb-4 font-medium text-daraz-dark">Payment Methods</h4>
            <div className="flex flex-wrap gap-2">
              <img src="https://ext.same-assets.com/3222324724/3394905855.png" alt="Payment Method" className="h-8" />
              <img src="https://ext.same-assets.com/3344067168/763255686.png" alt="Payment Method" className="h-8" />
            </div>

            <h4 className="mb-2 mt-6 font-medium text-daraz-dark">Verified by</h4>
            <img src="https://ext.same-assets.com/3017200192/257509588.png" alt="Verified" className="h-10" />
          </div>
        </div>
      </div>

      <div className="border-t border-gray-200 py-6 text-center text-xs text-gray-500">
        <div className="container-daraz">
          <p>© Daraz 2024</p>
        </div>
      </div>
    </footer>
  )
}
