import { useState, useEffect, useCallback } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

const slides = [
  {
    id: 1,
    text: "Welcome to Yellzy's Store",
  },
  {
    id: 2,
    text: "Best Gay Products",
  },
  {
    id: 3,
    text: "All items Rs.6 only",
  },
  {
    id: 4,
    text: "Limited Time Offers",
  },
  {
    id: 5,
    text: "Shop Now",
  }
]

export const HeroSlider = () => {
  const [current, setCurrent] = useState(0)
  const [direction, setDirection] = useState<'next' | 'prev'>('next')
  const [isAnimating, setIsAnimating] = useState(false)

  const nextSlide = useCallback(() => {
    if (isAnimating) return
    setIsAnimating(true)
    setDirection('next')
    setTimeout(() => {
      setCurrent(current => current === slides.length - 1 ? 0 : current + 1)
      setTimeout(() => setIsAnimating(false), 500)
    }, 50)
  }, [isAnimating])

  const prevSlide = useCallback(() => {
    if (isAnimating) return
    setIsAnimating(true)
    setDirection('prev')
    setTimeout(() => {
      setCurrent(current => current === 0 ? slides.length - 1 : current - 1)
      setTimeout(() => setIsAnimating(false), 500)
    }, 50)
  }, [isAnimating])

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide()
    }, 5000)

    return () => clearInterval(interval)
  }, [nextSlide])

  return (
    <div className="relative h-[300px] w-full overflow-hidden bg-yellzy-yellow">
      <div className="relative h-full">
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute top-0 flex h-full w-full items-center justify-center transition-all duration-500 ease-apple ${
              index === current
                ? 'z-10 opacity-100 transform translate-x-0 scale-100'
                : direction === 'next'
                  ? 'z-0 opacity-0 transform translate-x-full scale-95'
                  : 'z-0 opacity-0 transform -translate-x-full scale-95'
            }`}
          >
            <h1 className="text-4xl font-bold text-yellzy-dark animate-float">
              {slide.text}
            </h1>
          </div>
        ))}
      </div>

      <button
        className="absolute left-4 top-1/2 z-20 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white text-yellzy-dark shadow-lg transition-transform duration-300 ease-apple hover:scale-110 focus:outline-none"
        onClick={prevSlide}
        disabled={isAnimating}
      >
        <ChevronLeft size={24} />
      </button>

      <button
        className="absolute right-4 top-1/2 z-20 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white text-yellzy-dark shadow-lg transition-transform duration-300 ease-apple hover:scale-110 focus:outline-none"
        onClick={nextSlide}
        disabled={isAnimating}
      >
        <ChevronRight size={24} />
      </button>

      <div className="absolute bottom-6 left-1/2 z-20 flex -translate-x-1/2 space-x-3">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`h-2.5 w-2.5 rounded-full transition-all duration-300 ease-apple ${
              index === current
                ? 'bg-yellzy-dark w-8'
                : 'bg-white/50 hover:bg-white/80'
            }`}
            onClick={() => {
              if (isAnimating) return
              setDirection(index > current ? 'next' : 'prev')
              setIsAnimating(true)
              setTimeout(() => {
                setCurrent(index)
                setTimeout(() => setIsAnimating(false), 500)
              }, 50)
            }}
            disabled={isAnimating}
          />
        ))}
      </div>
    </div>
  )
}
