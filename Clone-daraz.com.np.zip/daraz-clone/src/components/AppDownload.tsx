import { Star } from "lucide-react"
import { useEffect, useState } from "react"

export const AppDownload = () => {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 400)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div
      className={`bg-white p-4 rounded-lg shadow-lg transition-all duration-700 ease-apple ${
        isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
      }`}
    >
      <h3 className="mb-4 font-bold text-yellzy-dark border-b border-yellzy-yellow/30 pb-2">Download the App</h3>

      <div className="rounded-lg bg-gradient-to-br from-yellzy-yellow/10 to-yellzy-yellow/20 p-4 transition-transform duration-500 ease-apple hover:scale-[1.02]">
        <div className="mb-3 text-center">
          <div className="mb-2 font-semibold text-yellzy-dark">4.8 Rated</div>
          <div className="flex justify-center">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star
                key={i}
                size={16}
                className={`transform transition-all duration-300 ease-apple ${i <= 5 ? "fill-yellow-400 text-yellow-400" : "text-gray-300"} ${i === 5 ? 'animate-float' : ''}`}
                style={{ animationDelay: `${i * 0.2}s` }}
              />
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <div className="overflow-hidden rounded-lg bg-white p-3 text-center text-sm shadow-sm transition-all duration-300 ease-apple hover:shadow-md hover:-translate-y-0.5">
            <span className="font-medium text-yellzy-dark">Free Delivery</span>
          </div>

          <div className="overflow-hidden rounded-lg bg-white p-3 text-center text-sm shadow-sm transition-all duration-300 ease-apple hover:shadow-md hover:-translate-y-0.5">
            <span className="font-medium text-yellzy-dark">Limited Time</span>
          </div>
        </div>

        <div className="mt-4 flex justify-center space-x-3">
          <a
            href="#"
            className="flex h-10 w-24 items-center justify-center rounded-lg bg-black shadow-md transition-transform duration-300 ease-apple hover:scale-105 active:scale-95"
          >
            <img
              src="https://ext.same-assets.com/3128849421/3113050248.png"
              alt="App Store"
              className="h-6 object-contain"
            />
          </a>

          <a
            href="#"
            className="flex h-10 w-24 items-center justify-center rounded-lg bg-black shadow-md transition-transform duration-300 ease-apple hover:scale-105 active:scale-95"
          >
            <img
              src="https://ext.same-assets.com/1035288574/3935604824.webp"
              alt="Google Play"
              className="h-6 object-contain"
            />
          </a>
        </div>

        <div className="mt-4 text-center text-xs text-yellzy-dark/80 animate-pulse-light">
          Download the App Now!
        </div>
      </div>
    </div>
  )
}
