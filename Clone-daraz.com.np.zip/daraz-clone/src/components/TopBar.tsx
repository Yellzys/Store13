import { Link } from "react-router-dom"

export const TopBar = () => {
  return (
    <div className="bg-yellzy-yellow text-yellzy-dark">
      <div className="container-daraz flex justify-between py-1 text-xs">
        <div className="hidden items-center space-x-4 lg:flex">
          <a href="#" className="hover:underline">
            Save More on App
          </a>
          <div className="h-3 w-[1px] bg-yellzy-dark/30"></div>
          <a href="#" className="hover:underline">
            Become a Seller
          </a>
          <div className="h-3 w-[1px] bg-yellzy-dark/30"></div>
          <a href="#" className="hover:underline">
            Help & Support
          </a>
        </div>
        <div className="ml-auto flex items-center space-x-4">
          <Link
            to="/login"
            className="transition-all duration-300 ease-apple hover:font-medium hover:text-yellzy-dark/70"
          >
            Login
          </Link>
          <div className="h-3 w-[1px] bg-yellzy-dark/30"></div>
          <Link
            to="/signup"
            className="transition-all duration-300 ease-apple hover:font-medium hover:text-yellzy-dark/70"
          >
            Sign Up
          </Link>
          <div className="h-3 w-[1px] bg-yellzy-dark/30"></div>
          <div className="flex items-center">
            <span>EN / English</span>
          </div>
        </div>
      </div>
    </div>
  )
}
