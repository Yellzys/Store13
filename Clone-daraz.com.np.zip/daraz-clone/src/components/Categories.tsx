import { useEffect, useState } from "react"

export const Categories = () => {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 200)

    return () => clearTimeout(timer)
  }, [])

  const categories = [
    { id: 1, name: "Breast Pump Accessories" },
    { id: 2, name: "Vinegar & Cooking Wine" },
    { id: 3, name: "Convertible" },
    { id: 4, name: "Other Projector Accessories" },
    { id: 5, name: "Kids Bookcases & Shelving" },
    { id: 6, name: "Canned" },
    { id: 7, name: "Toilet Paper" },
    { id: 8, name: "Hoodies & Sweatshirts" },
    { id: 9, name: "Bathroom Fittings" },
    { id: 10, name: "Habitats & Accessories" },
    { id: 11, name: "House Slippers" },
    { id: 12, name: "Christening" },
  ]

  return (
    <div
      className={`bg-white p-4 rounded-lg shadow-lg transition-all duration-700 ease-apple ${
        isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
      }`}
    >
      <h3 className="mb-4 font-bold text-yellzy-dark border-b border-yellzy-yellow/30 pb-2">Categories</h3>
      <ul className="space-y-2.5">
        {categories.map((category, index) => (
          <li
            key={category.id}
            style={{
              transitionDelay: `${index * 50}ms`,
              animation: `fade-in 0.5s ease-apple forwards ${index * 50 + 200}ms`
            }}
          >
            <a
              href={`/category/${category.id}`}
              className="group flex items-center text-sm text-gray-700 transition-all duration-300 ease-apple hover:text-yellzy-yellow"
            >
              <div className="mr-2 h-1.5 w-1.5 rounded-full bg-gray-300 transition-all duration-300 ease-apple group-hover:bg-yellzy-yellow group-hover:scale-125"></div>
              <span className="transition-all duration-300 ease-apple group-hover:translate-x-1">
                {category.name}
              </span>
            </a>
          </li>
        ))}
      </ul>
    </div>
  )
}
