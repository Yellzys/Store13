import { useState } from "react"
import { Lock, Mail, Eye, EyeOff } from "lucide-react"
import { Link } from "react-router-dom"

export const Login = () => {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      alert("Login successful!")
      // Redirect to home page in a real app
      window.location.href = "/"
    }, 1500)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex flex-1 items-center justify-center p-4">
        <div
          className="w-full max-w-md overflow-hidden rounded-2xl bg-white shadow-2xl"
          style={{ animation: "scale-in 0.6s cubic-bezier(0.23, 1, 0.32, 1) forwards" }}
        >
          <div className="bg-yellzy-yellow p-6 text-center">
            <h1 className="text-3xl font-bold text-yellzy-dark">Welcome Back</h1>
            <p className="mt-2 text-yellzy-dark/80">Sign in to your Yellzy's Store account</p>
          </div>

          <div className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div
                  className="relative"
                  style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.2s" }}
                >
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Email Address"
                    required
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-10 py-3 text-gray-700 outline-none transition-all duration-300 focus:border-yellzy-yellow focus:ring-2 focus:ring-yellzy-yellow/30"
                  />
                </div>

                <div
                  className="relative"
                  style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.4s" }}
                >
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    required
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 px-10 py-3 text-gray-700 outline-none transition-all duration-300 focus:border-yellzy-yellow focus:ring-2 focus:ring-yellzy-yellow/30"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-500 transition-all duration-300 hover:text-yellzy-dark"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <div
                className="flex items-center justify-between"
                style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.6s" }}
              >
                <div className="flex items-center">
                  <input
                    id="remember-me"
                    name="remember-me"
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-yellzy-yellow focus:ring-yellzy-yellow/50"
                  />
                  <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-700">
                    Remember me
                  </label>
                </div>

                <a href="#" className="text-sm font-medium text-yellzy-yellow hover:text-yellzy-dark">
                  Forgot password?
                </a>
              </div>

              <div
                style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.8s" }}
              >
                <button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full rounded-lg bg-yellzy-yellow py-3 font-semibold text-yellzy-dark transition-all duration-300 hover:bg-yellzy-dark hover:text-white ${
                    isLoading ? "cursor-not-allowed opacity-70" : ""
                  }`}
                >
                  {isLoading ? "Signing in..." : "Sign In"}
                </button>
              </div>
            </form>

            <div
              className="mt-6 text-center text-sm"
              style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 1s" }}
            >
              <span className="text-gray-600">Don't have an account?</span>{" "}
              <Link to="/signup" className="font-semibold text-yellzy-yellow hover:text-yellzy-dark">
                Sign Up
              </Link>
            </div>

            <div
              className="mt-4 text-center"
              style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 1.2s" }}
            >
              <Link to="/" className="text-xs text-gray-500 hover:text-yellzy-yellow">
                ← Back to Homepage
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
