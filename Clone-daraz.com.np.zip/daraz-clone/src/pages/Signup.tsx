import { useState } from "react"
import { Lock, Mail, Eye, EyeOff, User, Phone } from "lucide-react"
import { Link } from "react-router-dom"

export const Signup = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: ""
  })
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [step, setStep] = useState(1)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault()
    setStep(2)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      alert("Account created successfully!")
      // Redirect to login page in a real app
      window.location.href = "/login"
    }, 1500)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex flex-1 items-center justify-center p-4">
        <div
          className="w-full max-w-md overflow-hidden rounded-2xl bg-white shadow-2xl"
          style={{ animation: "scale-in 0.6s cubic-bezier(0.23, 1, 0.32, 1) forwards" }}
        >
          <div className="bg-yellzy-yellow p-6 text-center">
            <h1 className="text-3xl font-bold text-yellzy-dark">Create Account</h1>
            <p className="mt-2 text-yellzy-dark/80">Join Yellzy's Store today</p>
          </div>

          <div className="p-6">
            {step === 1 ? (
              <form onSubmit={handleNextStep} className="space-y-6">
                <div className="space-y-4">
                  <div
                    className="relative"
                    style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.2s" }}
                  >
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <User className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Full Name"
                      required
                      className="w-full rounded-lg border border-gray-300 bg-gray-50 px-10 py-3 text-gray-700 outline-none transition-all duration-300 focus:border-yellzy-yellow focus:ring-2 focus:ring-yellzy-yellow/30"
                    />
                  </div>

                  <div
                    className="relative"
                    style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.4s" }}
                  >
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="Email Address"
                      required
                      className="w-full rounded-lg border border-gray-300 bg-gray-50 px-10 py-3 text-gray-700 outline-none transition-all duration-300 focus:border-yellzy-yellow focus:ring-2 focus:ring-yellzy-yellow/30"
                    />
                  </div>

                  <div
                    className="relative"
                    style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.6s" }}
                  >
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Phone className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="Phone Number"
                      required
                      className="w-full rounded-lg border border-gray-300 bg-gray-50 px-10 py-3 text-gray-700 outline-none transition-all duration-300 focus:border-yellzy-yellow focus:ring-2 focus:ring-yellzy-yellow/30"
                    />
                  </div>
                </div>

                <div
                  style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.8s" }}
                >
                  <button
                    type="submit"
                    className="w-full rounded-lg bg-yellzy-yellow py-3 font-semibold text-yellzy-dark transition-all duration-300 hover:bg-yellzy-dark hover:text-white"
                  >
                    Continue
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div
                    className="relative"
                    style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.2s" }}
                  >
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type={showPassword ? "text" : "password"}
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                      placeholder="Password"
                      required
                      className="w-full rounded-lg border border-gray-300 bg-gray-50 px-10 py-3 text-gray-700 outline-none transition-all duration-300 focus:border-yellzy-yellow focus:ring-2 focus:ring-yellzy-yellow/30"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-500 transition-all duration-300 hover:text-yellzy-dark"
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>

                  <div
                    className="relative"
                    style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.4s" }}
                  >
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type={showPassword ? "text" : "password"}
                      name="confirmPassword"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      placeholder="Confirm Password"
                      required
                      className="w-full rounded-lg border border-gray-300 bg-gray-50 px-10 py-3 text-gray-700 outline-none transition-all duration-300 focus:border-yellzy-yellow focus:ring-2 focus:ring-yellzy-yellow/30"
                    />
                  </div>
                </div>

                <div
                  className="flex justify-between"
                  style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.6s" }}
                >
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="rounded-lg border border-yellzy-yellow bg-white px-4 py-3 font-semibold text-yellzy-yellow transition-all duration-300 hover:bg-yellzy-yellow/10"
                  >
                    Back
                  </button>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className={`rounded-lg bg-yellzy-yellow px-8 py-3 font-semibold text-yellzy-dark transition-all duration-300 hover:bg-yellzy-dark hover:text-white ${
                      isLoading ? "cursor-not-allowed opacity-70" : ""
                    }`}
                  >
                    {isLoading ? "Creating Account..." : "Create Account"}
                  </button>
                </div>
              </form>
            )}

            <div
              className="mt-6 text-center text-sm"
              style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 0.8s" }}
            >
              <span className="text-gray-600">Already have an account?</span>{" "}
              <Link to="/login" className="font-semibold text-yellzy-yellow hover:text-yellzy-dark">
                Sign In
              </Link>
            </div>

            <div
              className="mt-4 text-center"
              style={{ animation: "fade-in 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards 1s" }}
            >
              <Link to="/" className="text-xs text-gray-500 hover:text-yellzy-yellow">
                ← Back to Homepage
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
